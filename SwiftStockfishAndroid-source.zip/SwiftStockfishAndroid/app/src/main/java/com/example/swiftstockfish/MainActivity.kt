package com.example.swiftstockfish

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var boardGrid: GridLayout
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var analyzeButton: Button
    private var selected = -1
    private var fen = START_FEN
    private val board = CharArray(64)
    private val pieces = mapOf('K' to "♔", 'Q' to "♕", 'R' to "♖", 'B' to "♗", 'N' to "♘", 'P' to "♙", 'k' to "♚", 'q' to "♛", 'r' to "♜", 'b' to "♝", 'n' to "♞", 'p' to "♟", '.' to "")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        parseFen(START_FEN)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 20, 16, 16); setBackgroundColor(Color.rgb(24, 27, 32)) }
        root.addView(TextView(this).apply { text = "SWIFT STOCKFISH"; textSize = 24f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0, 4, 0, 4) })
        root.addView(TextView(this).apply { text = "Analisis catur • ringan • offline"; textSize = 14f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0, 0, 0, 16) })
        boardGrid = GridLayout(this).apply { columnCount = 8; rowCount = 8; useDefaultMargins = false }
        root.addView(boardGrid)
        status = TextView(this).apply { textSize = 14f; setTextColor(Color.WHITE); setPadding(4, 12, 4, 8) }
        root.addView(status)
        analyzeButton = Button(this).apply { text = "ANALISIS LANGKAH TERBAIK"; setOnClickListener { analyze() } }
        root.addView(analyzeButton)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        controls.addView(Button(this).apply { text = "Posisi awal"; setOnClickListener { parseFen(START_FEN); fen = START_FEN; selected = -1; renderBoard(); result.text = "Posisi awal dipulihkan." } })
        controls.addView(Button(this).apply { text = "Salin FEN"; setOnClickListener { val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager; cm.setPrimaryClip(android.content.ClipData.newPlainText("FEN", fen)); result.text = "FEN disalin: $fen" } })
        root.addView(controls)
        result = TextView(this).apply { textSize = 14f; setTextColor(Color.rgb(190, 225, 190)); setPadding(4, 12, 4, 4); text = "Siap. Pilih bidak untuk melihat petak tujuan, lalu analisis." }
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
        renderBoard()
        if (!engineFile().exists()) status.text = "Mesin Stockfish belum dipasang. Lihat README.md untuk menambah binary UCI yang sesuai." 
    }

    private fun renderBoard() {
        boardGrid.removeAllViews()
        for (i in 0 until 64) {
            val r = i / 8; val c = i % 8
            val b = Button(this).apply {
                text = pieces[board[i]] ?: ""
                textSize = 29f
                minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
                setPadding(0, 0, 0, 0)
                setTextColor(if (board[i].isUpperCase()) Color.WHITE else Color.BLACK)
                setBackgroundColor(if (i == selected) Color.rgb(245, 210, 70) else if ((r + c) % 2 == 0) Color.rgb(238, 216, 181) else Color.rgb(181, 136, 99))
                setOnClickListener { onSquare(i) }
            }
            boardGrid.addView(b, GridLayout.LayoutParams().apply { width = 0; height = (resources.displayMetrics.widthPixels - 32) / 8; columnSpec = GridLayout.spec(c, 1f); rowSpec = GridLayout.spec(r) })
        }
        status.text = "Posisi: ${if (fen.split(" ").getOrNull(1) == "w") "Putih" else "Hitam"} bergerak • FEN siap dianalisis"
    }

    private fun onSquare(i: Int) {
        if (selected < 0) {
            if (board[i] != '.') { selected = i; result.text = "Petak ${square(i)} dipilih. Ketuk petak tujuan untuk memindahkan bidak." }
        } else if (selected == i) {
            selected = -1
        } else {
            val from = square(selected); val to = square(i)
            // Basic board editor: moves are for arranging an analysis position; Stockfish validates/analyzes the final position.
            board[i] = board[selected]; board[selected] = '.'; selected = -1
            fen = boardToFen()
            result.text = "Posisi diedit ($from → $to). Ini editor posisi sederhana; aturan langkah belum divalidasi. Tekan Analisis untuk menilai posisi." 
        }
        renderBoard()
    }

    private fun analyze() {
        val engine = engineFile()
        if (!engine.exists()) {
            result.text = "Mesin belum tersedia. Tambahkan file executable Stockfish UCI untuk Android arm64-v8a ke app/src/main/assets/engine/arm64-v8a/stockfish lalu build ulang. Lihat README.md."
            return
        }
        analyzeButton.isEnabled = false
        result.text = "Menjalankan Stockfish…"
        executor.execute {
            val output = try { runUci(engine, fen) } catch (e: Exception) { "Gagal menjalankan mesin: ${e.message}" }
            runOnUiThread { result.text = output; analyzeButton.isEnabled = true }
        }
    }

    private fun engineFile(): File {
        val dest = File(filesDir, "stockfish")
        if (!dest.exists()) {
            try { assets.open("engine/arm64-v8a/stockfish").use { input -> dest.outputStream().use { output -> input.copyTo(output) } }; dest.setExecutable(true) } catch (_: Exception) { }
        }
        return dest
    }

    private fun runUci(engine: File, position: String): String {
        val process = ProcessBuilder(engine.absolutePath).redirectErrorStream(true).start()
        val writer = process.outputStream.bufferedWriter()
        val reader = process.inputStream.bufferedReader()
        writer.write("uci\n"); writer.flush()
        var line: String
        var loops = 0
        while (loops++ < 500 && (reader.readLine() ?: break) != "uciok") {}
        writer.write("isready\n"); writer.flush()
        loops = 0
        while (loops++ < 100 && (reader.readLine() ?: break) != "readyok") {}
        writer.write("setoption name Threads value 2\n")
        writer.write("setoption name Hash value 32\n")
        writer.write("position fen $position\n")
        writer.write("go movetime 700\n"); writer.flush()
        var best = "Belum ada langkah terbaik."
        val deadline = System.currentTimeMillis() + 2500
        while (System.currentTimeMillis() < deadline) {
            val lineOut = reader.readLine() ?: break
            if (lineOut.startsWith("info ") && lineOut.contains(" score ")) best = lineOut
            if (lineOut.startsWith("bestmove ")) { best = "Langkah terbaik: ${lineOut.split(" ").getOrNull(1) ?: "?"}\n$best"; break }
        }
        writer.write("quit\n"); writer.flush()
        process.waitFor(1, TimeUnit.SECONDS); process.destroyForcibly()
        return best
    }

    private fun parseFen(value: String) {
        val rows = value.split(" ")[0].split("/")
        var k = 0
        for (row in rows) for (ch in row) if (ch.isDigit()) repeat(ch.digitToInt()) { if (k < 64) board[k++] = '.' } else if (k < 64) board[k++] = ch
        while (k < 64) board[k++] = '.'
    }

    private fun boardToFen(): String {
        val ranks = (0..7).map { r ->
            var empty = 0; val out = StringBuilder()
            for (c in 0..7) { val p = board[r * 8 + c]; if (p == '.') empty++ else { if (empty > 0) { out.append(empty); empty = 0 }; out.append(p) } }
            if (empty > 0) out.append(empty); out.toString()
        }
        val turn = fen.split(" ").getOrNull(1) ?: "w"
        return ranks.joinToString("/") + " $turn - - 0 1"
    }

    private fun square(i: Int) = "${'a' + i % 8}${8 - i / 8}"

    companion object {
        private const val START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
    }
}
