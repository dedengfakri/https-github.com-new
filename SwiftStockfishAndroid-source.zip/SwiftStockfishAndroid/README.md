# SwiftStockfishAndroid — proyek sumber

Kerangka aplikasi Android sederhana untuk mengedit posisi catur dan meminta langkah terbaik dari mesin UCI Stockfish. Pengaturan awal dibuat ringan (2 thread, hash 32 MB, pencarian singkat).

## Status penting

- Ini adalah **proyek sumber**, bukan APK siap instal.
- Mesin Stockfish Android **belum disertakan**. Tanpa binary mesin yang cocok, fitur analisis tidak akan mengembalikan langkah terbaik.
- Papan saat ini adalah editor posisi sederhana, belum memvalidasi seluruh aturan catur.
- Jangan menyalin binary dari APK pihak lain. Gunakan binary yang diperoleh/dibangun secara sah dan patuhi lisensi GPL Stockfish.

## Membuat APK hanya dengan HP Android (build cloud)

1. Unduh ZIP ini lalu ekstrak dengan aplikasi pengelola file Android.
2. Di browser HP, buka https://github.com dan buat akun/masuk.
3. Buat repository baru bernama `SwiftStockfishAndroid`.
4. Unggah **isi folder** proyek ini ke repository (termasuk folder tersembunyi `.github/workflows`). Struktur repository harus menampilkan `app`, `build.gradle.kts`, `settings.gradle.kts`, dan `.github` di bagian paling atas.
5. Buka tab **Actions**, pilih workflow **Build Android APK**, lalu tekan **Run workflow**. Jika diminta, aktifkan Actions.
6. Setelah selesai, buka hasil workflow yang sukses, gulir ke **Artifacts**, lalu unduh `SwiftStockfishAndroid-debug-apk`.
7. Ekstrak ZIP artifact yang diunduh. Di dalamnya ada `app-debug.apk`; ketuk file itu untuk memasang. Android mungkin meminta izin **Install unknown apps** untuk browser/pengelola file yang digunakan.

Catatan: workflow ini hanya membangun proyek. Ia tidak menambahkan Stockfish secara otomatis; APK yang dihasilkan belum bisa memberi analisis Stockfish sampai binary mesin Android ARM64 yang cocok ditambahkan ke `app/src/main/assets/engine/arm64-v8a/stockfish`.

## Membangun di komputer

Gunakan JDK 17, Android SDK API 35, dan Gradle 8.9. Jalankan `gradle assembleDebug` dari folder proyek.

## Pengaturan performa

Di `MainActivity.kt`, waktu pencarian dapat disesuaikan. Nilai lebih pendek biasanya lebih cepat tetapi analisis lebih dangkal. Untuk HP dengan RAM terbatas, mulai dari 1–2 thread dan hash 16–32 MB.

## Lisensi

Kode kerangka ini terpisah dari mesin Stockfish. Jika menggabungkan atau mendistribusikan Stockfish, patuhi lisensi dan kewajiban sumber kode dari versi yang digunakan.
